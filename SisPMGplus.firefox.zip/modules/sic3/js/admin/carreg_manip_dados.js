// Grupo 3: Carregamento e Manipulação de Dados

  async function carregarInformacoesAdmin() {
    try {
      const userMLog = typeof mLog != "undefined" ? mLog : "";

      const condicaoWhere =
        userMLog === "admin" ? "A IS NOT NULL" : `A = '${userMLog}'`;

      const [conveniosData, anosData] = await Promise.all([
        carregarDadosPlanilha({
          sheetId: idbase,
          sheet: "convenios",
          query: `SELECT A,B,C,D,E,F,G,H,M,X,Y WHERE ${condicaoWhere}`,
        }),
        carregarDadosPlanilha({
          sheetId: idbase,
          sheet: "principal",
          query: "SELECT D WHERE D IS NOT NULL",
        }),
      ]);

      ADMIN_CONFIG.dados.convenios = [];

      let dadosParaProcessar = [];
      if (conveniosData && conveniosData.length > 0) {
        dadosParaProcessar = (userMLog === "admin") ? conveniosData.slice(1) : conveniosData;
      }
      if (dadosParaProcessar.length > 0) {
        dadosParaProcessar.forEach((row) => {
          const [
            municipio,
            convenio,
            preposto_n,
            preposto_pg,
            preposto,
            unidade,
            dataInicio,
            dataFim,
            status_texto,
            elementos_despesa,
            user_pm
          ] = row;
          if (municipio) {
            ADMIN_CONFIG.dados.convenios.push({
              municipio: String(municipio).trim(),
              convenio: String(convenio).trim(),
              preposto_n: String(preposto_n || "").trim(),
              preposto_pg: String(preposto_pg || "").trim(),
              preposto: String(preposto || "").trim(),
              unidade: String(unidade || "").trim(),
              dataInicio: String(dataInicio || "").trim(),
              dataFim: String(dataFim || "").trim(),
              status_texto: String(status_texto || "").trim(),
              elementos_despesa: String(elementos_despesa || "").trim(),
              user_pm: String(user_pm || "").trim()
            });
          }
        });
      }

      const anoAtual = new Date().getFullYear();
      const anoAnterior = anoAtual - 1;
      const todosAnos =
        anosData && anosData.length > 1
          ? anosData.slice(1).map((row) => String(row[0]).trim())
          : [];
      todosAnos.push(anoAtual.toString(), anoAnterior.toString());
      ADMIN_CONFIG.dados.anos = [...new Set(todosAnos)]
        .filter((a) => a && /^\d{4}$/.test(a))
        .sort((a, b) => b - a);

      await preencherSelectsAdmin(ADMIN_CONFIG.dados);
      return ADMIN_CONFIG.dados;
    } catch (error) {
      manipularErro(error, "carregarInformacoesAdmin");
      throw new Error(
        "Não foi possível carregar as informações administrativas."
      );
    }
  }

  async function carregarDadosBrutosAdmin(ano, mes) {
    try {
      const queryStatus =
        `SELECT A,B,C,D,E,F,H,I,J,K,L,M,N,O,P,Q,R,S WHERE D='${ano}'` +
        (mes !== "TODOS" ? ` AND E='${mes}'` : "");

      const [statusInfoRaw] = await Promise.all([
        carregarDadosPlanilha({
          sheetId: idbase,
          sheet: "obsgeral",
          query: queryStatus,
        }),
      ]);

      const statusInfoFiltrados =
        statusInfoRaw.length > 1 ? statusInfoRaw : [];

      return { status: statusInfoFiltrados };
    } catch (error) {
      // Silencia o erro para evitar travar a tela em caso de aba obsgeral vazia ou incompleta
      manipularErro(error, "carregarDadosBrutosAdmin", true);
      return { principal: [], status: [] };
    }
  }

  async function carregarLancamentos() {
    const municipioFiltro = $("#municipio").val();
    const convenioFiltro = $("#convenio").val();
    const ano = $("#ano").val();
    const mesFiltro = $("#mes").val();

    if (!municipioFiltro || !ano) {
      $("#tabela-lancamentos tbody")
        .empty()
        .append(
          '<tr><td colspan="10" class="text-center">Selecione Município e Ano.</td></tr>'
        );
      return;
    }

    if (municipioFiltro === "TODOS" && mesFiltro === "TODOS") {
      mostrarDialogo(
        "Aviso",
        "Para a opção 'TODOS OS MUNICÍPIOS', por favor, selecione um MÊS específico. Ou, para 'TODOS OS MESES', selecione um MUNICÍPIO específico."
      );
      $("#tabela-lancamentos tbody")
        .empty()
        .append(
          '<tr><td colspan="10" class="text-center">Seleção de filtros inválida.</td></tr>'
        );
      ADMIN_CONFIG.lancamentosCarregados = true;
      return;
    }

    if (municipioFiltro !== "TODOS" && convenioFiltro === "-") {
      $("#tabela-lancamentos tbody")
        .empty()
        .append(
          `<tr><td colspan="10" class="text-center">Não há convênios ativos para ${municipioFiltro} no período selecionado ou para os filtros aplicados.</td></tr>`
        );
      atualizarCabecalhoTabela();
      ADMIN_CONFIG.lancamentosCarregados = true;
      return;
    }

    atualizarCabecalhoTabela();
    mostrarCarregamento();

    try {
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("Tempo esgotado")), 30000)
      );
      const dadosBrutos = await Promise.race([
        carregarDadosBrutosAdmin(ano, mesFiltro),
        timeoutPromise,
      ]);
      const lancamentosParaTabela = [];
      const mesesNomes = [
        "JANEIRO",
        "FEVEREIRO",
        "MARÇO",
        "ABRIL",
        "MAIO",
        "JUNHO",
        "JULHO",
        "AGOSTO",
        "SETEMBRO",
        "OUTUBRO",
        "NOVEMBRO",
        "DEZEMBRO",
      ];

      if (municipioFiltro === "TODOS") {
        const municipiosUnicos = [
          ...new Set(
            ADMIN_CONFIG.dados.convenios
              .map((c) => c.municipio)
              .filter((m) => m && m !== "ADMIN")
          ),
        ].sort();

        municipiosUnicos.forEach((mun) => {
          const conveniosDoMunicipioNoMes = ADMIN_CONFIG.dados.convenios.filter(
            (item) =>
              item.municipio === mun &&
              item.convenio !== "-" &&
              verificarVigenciaConvenio(item, ano, mesFiltro) &&
              (convenioFiltro === "TODOS" || item.status_texto === convenioFiltro)
          );
          if (conveniosDoMunicipioNoMes.length > 0) {
            conveniosDoMunicipioNoMes.forEach((conv) => {
              const statusRowConv = dadosBrutos.status.find(
                (s) =>
                  String(s[1]).trim() === conv.municipio &&
                  String(s[2]).trim() === conv.convenio &&
                  String(s[3]).trim() === ano &&
                  String(s[4]).trim() === mesFiltro
              );
              lancamentosParaTabela.push({
                timestamp:
                  statusRowConv && statusRowConv[0]
                    ? String(statusRowConv[0]).trim()
                    : "",
                municipio: conv.municipio,
                convenio: conv.convenio,
                ano,
                mes: mesFiltro,
                valorTotal:
                  statusRowConv && statusRowConv[5]
                    ? formatarNumero(statusRowConv[5], "numero")
                    : "",
                edicaoBloqueada: statusRowConv
                  ? String(statusRowConv[6]).trim() === "SIM"
                  : false,
                sirconvStatus:
                  statusRowConv && statusRowConv[8]
                    ? String(statusRowConv[8]).trim()
                    : "",
                siadStatus:
                  statusRowConv && statusRowConv[9]
                    ? String(statusRowConv[9]).trim()
                    : "",
                siadInfo: statusRowConv ? {
                  colL: statusRowConv[10] ? String(statusRowConv[10]).trim() : "",
                  colM: statusRowConv[11] ? String(statusRowConv[11]).trim() : "",
                  colN: statusRowConv[12] ? String(statusRowConv[12]).trim() : "",
                  colO: statusRowConv[13] ? String(statusRowConv[13]).trim() : "",
                  colP: statusRowConv[14] ? String(statusRowConv[14]).trim() : "",
                  colQ: statusRowConv[15] ? String(statusRowConv[15]).trim() : "",
                  colR: statusRowConv[16] ? String(statusRowConv[16]).trim() : "",
                  colS: statusRowConv[17] ? String(statusRowConv[17]).trim() : "",
                } : null,
                semConvenio: false,
              });
            });
          } else {
            if (convenioFiltro === "TODOS") {
              lancamentosParaTabela.push({
                municipio: mun,
                convenio: "-",
                ano,
                mes: mesFiltro,
                valorTotal: 0,
                edicaoBloqueada: false,
                sirconvStatus: "",
                siadStatus: "",
                timestamp: "",
                semConvenio: true,
              });
            }
          }
        });
      } else {
        const conveniosDoMunicipio = ADMIN_CONFIG.dados.convenios.filter(
          (item) => item.municipio === municipioFiltro && item.convenio !== "-"
        );
        const mesesAIterar = mesFiltro === "TODOS" ? mesesNomes : [mesFiltro];

        mesesAIterar.forEach((nomeMesCorrente) => {
          let linhasAdicionadasParaEsteMes = 0;
          let conveniosParaEsteMes = [];

          if (convenioFiltro === "TODOS") {
            conveniosParaEsteMes = conveniosDoMunicipio.filter((conv) =>
              verificarVigenciaConvenio(conv, ano, nomeMesCorrente)
            );
          } else {
            const convEsp = conveniosDoMunicipio.find(
              (c) => c.convenio === convenioFiltro
            );
            if (
              convEsp &&
              verificarVigenciaConvenio(convEsp, ano, nomeMesCorrente)
            ) {
              conveniosParaEsteMes.push(convEsp);
            }
          }

          if (conveniosParaEsteMes.length > 0) {
            conveniosParaEsteMes.forEach((conv) => {
              const statusRowConv = dadosBrutos.status.find(
                (s) =>
                  String(s[1]).trim() === municipioFiltro &&
                  String(s[2]).trim() === conv.convenio &&
                  String(s[3]).trim() === ano &&
                  String(s[4]).trim() === nomeMesCorrente
              );
              lancamentosParaTabela.push({
                timestamp:
                  statusRowConv && statusRowConv[0]
                    ? String(statusRowConv[0]).trim()
                    : "",
                municipio: municipioFiltro,
                convenio: conv.convenio,
                ano,
                mes: nomeMesCorrente,
                valorTotal:
                  statusRowConv && statusRowConv[5]
                    ? formatarNumero(statusRowConv[5], "numero")
                    : "",
                edicaoBloqueada: statusRowConv
                  ? String(statusRowConv[6]).trim() === "SIM"
                  : false,
                sirconvStatus:
                  statusRowConv && statusRowConv[8]
                    ? String(statusRowConv[8]).trim()
                    : "",
                siadStatus:
                  statusRowConv && statusRowConv[9]
                    ? String(statusRowConv[9]).trim()
                    : "",
                siadInfo: statusRowConv ? {
                  colL: statusRowConv[10] ? String(statusRowConv[10]).trim() : "",
                  colM: statusRowConv[11] ? String(statusRowConv[11]).trim() : "",
                  colN: statusRowConv[12] ? String(statusRowConv[12]).trim() : "",
                  colO: statusRowConv[13] ? String(statusRowConv[13]).trim() : "",
                  colP: statusRowConv[14] ? String(statusRowConv[14]).trim() : "",
                  colQ: statusRowConv[15] ? String(statusRowConv[15]).trim() : "",
                  colR: statusRowConv[16] ? String(statusRowConv[16]).trim() : "",
                  colS: statusRowConv[17] ? String(statusRowConv[17]).trim() : "",
                } : null,
                semConvenio: false,
              });
              linhasAdicionadasParaEsteMes++;
            });
          }

          if (linhasAdicionadasParaEsteMes === 0) {
            let convDisplayParaPlaceholder = "-";
            if (convenioFiltro !== "TODOS") {
              const convEspecificoSelecionado = conveniosDoMunicipio.find(
                (c) => c.convenio === convenioFiltro
              );
              if (
                convEspecificoSelecionado &&
                !verificarVigenciaConvenio(
                  convEspecificoSelecionado,
                  ano,
                  nomeMesCorrente
                )
              ) {
                convDisplayParaPlaceholder = "-";
              } else if (convEspecificoSelecionado) {
                convDisplayParaPlaceholder = convenioFiltro;
              }
            }

            lancamentosParaTabela.push({
              municipio: municipioFiltro,
              convenio: convDisplayParaPlaceholder,
              ano,
              mes: nomeMesCorrente,
              valorTotal: 0,
              edicaoBloqueada: false,
              sirconvStatus: "",
              siadStatus: "",
              timestamp: "",
              semConvenio: true,
            });
          }
        });
      }

      lancamentosParaTabela.sort((a, b) => {
        const municipioCompare = a.municipio.localeCompare(b.municipio);
        if (municipioCompare !== 0) return municipioCompare;

        const mesesOrdem = [
          "JANEIRO",
          "FEVEREIRO",
          "MARÇO",
          "ABRIL",
          "MAIO",
          "JUNHO",
          "JULHO",
          "AGOSTO",
          "SETEMBRO",
          "OUTUBRO",
          "NOVEMBRO",
          "DEZEMBRO",
        ];
        const indexA = mesesOrdem.indexOf(a.mes);
        const indexB = mesesOrdem.indexOf(b.mes);
        if (indexA !== indexB) return indexA - indexB;

        const convA = String(a.convenio).trim();
        const convB = String(b.convenio).trim();
        const numA = parseInt(convA);
        const numB = parseInt(convB);
        const isNumA = !isNaN(numA) && String(numA) === convA;
        const isNumB = !isNaN(numB) && String(numB) === convB;

        if (isNumA && isNumB) return numA - numB;
        if (isNumA) return -1;
        if (isNumB) return 1;
        if (convA === "-") return -1;
        if (convB === "-") return 1;
        return convA.localeCompare(convB);
      });

      preencherTabelaLancamentosAdmin(lancamentosParaTabela);
      ADMIN_CONFIG.lancamentosCarregados = true;
    } catch (error) {
      manipularErro(error, "carregarLancamentos");
      $("#tabela-lancamentos tbody")
        .empty()
        .append(
          '<tr><td colspan="10" class="text-center">Erro ao carregar lançamentos. Tente novamente.</td></tr>'
        );
    } finally {
      ocultarCarregamento();
    }
  }
