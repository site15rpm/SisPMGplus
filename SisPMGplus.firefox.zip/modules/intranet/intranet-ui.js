// Arquivo: modules/intranet/intranet-ui.js
// Contém a lógica para o menu intranet da extensão.
import { sendMessageToBackground, getCookie, decodeJwt } from '../../common/utils.js';

/**
 * Verifica se o usuário atende aos critérios de abrangência.
 * A lógica é OR: o usuário precisa satisfazer pelo menos UM dos critérios definidos.
 * Dentro de um critério (ex: g:123|456), a lógica é OR (bater com 123 OU 456).
 * @param {string} abrangenciaString - A string de regras (ex: "g:123|456, t:SGT, f:29\..*").
 * @param {object} userData - O objeto com os dados do usuário do token.
 * @returns {boolean} - True se o usuário tiver acesso, false caso contrário.
 */
function checkAbrangencia(abrangenciaString, userData) {
    if (!abrangenciaString) return false; // Sem regra, sem acesso
    const upperString = abrangenciaString.toUpperCase();
    
    // "PMMG" ou "1" concede acesso universal
    if (upperString === "PMMG" || upperString === "1") return true;

    const allCriteria = abrangenciaString.split(',');
    if (allCriteria.length === 0) return false; // String vazia ou mal formatada

    // Lógica OR: O usuário precisa corresponder a pelo menos UM critério (g, t, p, etc.)
    for (const criterion of allCriteria) {
        const parts = criterion.split(':');
        if (parts.length < 2) continue; // Parte da regra mal formatada, ignora

        const key = parts[0].trim().toLowerCase(); // e.g., 'g', 't', 'p', 'f', 'fl', 'ff'
        const rules = parts.slice(1).join(':').trim(); // e.g., '123|456' or '.*RPM.*'
        const ruleList = rules.split('|').map(r => r.trim()).filter(r => r); // Alterado de ';' para '|'

        // Se a chave não for um critério válido ou não houver regras para ela, pula para o próximo critério
        if (!userData.hasOwnProperty(key) || ruleList.length === 0) {
            continue;
        }

        const userValue = userData[key];
        let criteriaMet = false;

        // Modificado para incluir 'f', 'fl', e 'ff' na lógica de array
        if ((key === 'f' || key === 'fl' || key === 'ff') && Array.isArray(userValue)) {
            // Para 'f', 'fl', 'ff', verifica se ALGUM item do usuário bate com ALGUMA regra
            for (const userItem of userValue) {
                for (const rule of ruleList) {
                    try {
                        // Compara usando Regex, case-insensitive
                        if (new RegExp('^' + rule + '$', 'i').test(userItem)) {
                            criteriaMet = true;
                            break;
                        }
                    } catch (e) {
                        // Fallback para correspondência exata se a regex for inválida
                        if (userItem === rule) criteriaMet = true;
                    }
                }
                if (criteriaMet) break; // Já achou um item que bate
            }
        } else if (typeof userValue === 'string') {
            // Para outros (g, t, p, r, u, c), verifica se O valor do usuário bate com ALGUMA regra
            for (const rule of ruleList) {
                try {
                    // Compara usando Regex, case-insensitive
                    if (new RegExp('^' + rule + '$', 'i').test(userValue)) {
                        criteriaMet = true;
                        break;
                    }
                } catch (e) {
                    // Fallback para correspondência exata se a regex for inválida
                    if (userValue === rule) criteriaMet = true;
                }
            }
        }

        // Se este critério foi satisfeito, a regra inteira (OR) é satisfeita.
        if (criteriaMet) {
            return true;
        }
    }

    // Se passou por todos os critérios e nenhum deu 'true', o acesso é negado.
    return false;
}


export class UIModule {
    constructor(config) {
        this.config = config;
        this.iconSVG = config.iconSVG_28;
        this.modules = {};
        this.menuVisible = false;
        this.iconContainer = null;
        this.menuCloseTimer = null; // Temporizador para o fechamento do menu
        this.preloadedMenuContent = null; // Conteúdo pré-carregado do menu
        this.isMenuContentLoading = false; // Flag para evitar carregamentos múltiplos
        this.preloadDebounceTimer = null; // Timer para debouncing do pré-carregamento
    }

    async init() {
        window.SisPMG_UI = this; // Torna a instância da UI globalmente acessível
        this.injectGlobalContainer();
        this.hideHelpIcon();
        this.injectHeaderIcon();
        this.preloadHeaderMenuContent(); // Pré-carrega o conteúdo do menu

        // Escuta atualizações de links em tempo real enviadas pelo background
        window.addEventListener('message', (event) => {
            if (event.source === window && event.data?.type === 'FROM_SISPMG_BACKGROUND') {
                if (event.data?.action === 'links-updated') {
                    console.log('SisPMG+ [UI]: Atualização de links dinâmicos recebida. Recarregando menu...');
                    this.preloadHeaderMenuContent(true); // Força o recarregamento
                }
            }
        });
    }

    async preloadHeaderMenuContent(force = false) {
        // Previne carregamentos paralelos. Se já está carregando, a chamada atual é ignorada.
        // A lógica de debounce em registerModule garante que a última chamada será executada.
        if (this.isMenuContentLoading) return; 

        // Se não for forçado, evita recarregar se o conteúdo já existir.
        if (!force && this.preloadedMenuContent) {
            return;
        }

        this.isMenuContentLoading = true;
        try {
            this.preloadedMenuContent = await this.getHeaderMenuContent();
        } catch (error) {
            console.error("SisPMG+ [UI]: Erro ao pré-carregar o conteúdo do menu.", error);
            this.preloadedMenuContent = '<div class="sispmg-menu-item sispmg-menu-error">Erro ao carregar menu.</div>';
        } finally {
            this.isMenuContentLoading = false;
            // Se o menu estiver aberto, atualiza seu conteúdo com os novos dados.
            if (this.menuVisible) {
                this.updateMenu();
            }
        }
    }
    
    injectGlobalContainer() {
        if (document.getElementById('sispmg-plus-container')) return;

        const createContainer = () => {
            if (document.getElementById('sispmg-plus-container') || !document.body) return;
            const container = document.createElement('div');
            container.id = 'sispmg-plus-container';
            document.body.appendChild(container);
        };

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', createContainer);
        } else {
            createContainer();
        }
    }

    hideHelpIcon() {
        const headerAjuda = document.getElementById('headerAjuda');
        if (headerAjuda) {
            headerAjuda.style.display = 'none';
        }
    }

    registerModule(module) {
        this.modules[module.name] = module.instance;
        
        clearTimeout(this.preloadDebounceTimer);
        this.preloadDebounceTimer = setTimeout(() => {
            this.preloadHeaderMenuContent(true); // Força o recarregamento
        }, 150);
    }
    
    unregisterModule(moduleName) {
        delete this.modules[moduleName];

        clearTimeout(this.preloadDebounceTimer);
        this.preloadDebounceTimer = setTimeout(() => {
            this.preloadHeaderMenuContent(true); // Força o recarregamento
        }, 150);
    }

    injectHeaderIcon() {
        const headerCheckInterval = setInterval(() => {
            const avatarElement = document.getElementById('u1');
            const iconExists = document.getElementById('sispmg-plus-header-icon');

            if (avatarElement && !iconExists) {
                this.iconContainer = document.createElement('a');
                this.iconContainer.href = '#';
                this.iconContainer.id = 'sispmg-plus-header-icon';
                this.iconContainer.title = 'SisPMG+';
                this.iconContainer.innerHTML = this.iconSVG;

                // Modificado: Abrir com mouseenter
                this.iconContainer.addEventListener('mouseenter', () => {
                    if (this.menuCloseTimer) clearTimeout(this.menuCloseTimer);
                    this.menuCloseTimer = null;
                    if (!this.menuVisible) {
                        this.openHeaderMenu();
                    }
                });

                // Modificado: Iniciar timer para fechar com mouseleave
                this.iconContainer.addEventListener('mouseleave', () => {
                    this.menuCloseTimer = setTimeout(() => this.closeHeaderMenu(), 300);
                });
                
                avatarElement.insertAdjacentElement('beforebegin', this.iconContainer);
                
                clearInterval(headerCheckInterval);
            }
        }, 500);
    }
    
    toggleHeaderMenu() {
        this.menuVisible ? this.closeHeaderMenu() : this.openHeaderMenu();
    }
    
    async openHeaderMenu() {
        if (this.menuVisible) return;
        this.menuVisible = true;
        
        if (!this.iconContainer) return;
    
        const menu = document.createElement('div');
        menu.id = 'sispmg-plus-header-menu';
        menu.className = 'sispmg-plus-menu'; 

        // Usa o conteúdo pré-carregado ou mostra "Carregando..."
        const content = this.preloadedMenuContent 
            ? `<div>${this.preloadedMenuContent}</div>`
            : `<div><div class="sispmg-menu-header">Carregando...</div></div>`;

        menu.innerHTML = content;
        document.getElementById('sispmg-plus-container').appendChild(menu);

        const iconRect = this.iconContainer.getBoundingClientRect();
        Object.assign(menu.style, {
            top: `${iconRect.bottom + 5}px`,
            left: 'auto',
            right: `${window.innerWidth - iconRect.right}px`
        });
        
        // Modificado: Listeners de mouse para o menu (para manter aberto)
        menu.addEventListener('mouseenter', () => {
            if (this.menuCloseTimer) clearTimeout(this.menuCloseTimer);
            this.menuCloseTimer = null;
        });

        menu.addEventListener('mouseleave', () => {
            this.menuCloseTimer = setTimeout(() => this.closeHeaderMenu(), 300);
        });

        this.attachMenuEventListeners(menu);

        // Se o conteúdo não estava pronto (raro), tenta carregar de novo em segundo plano
        if (!this.preloadedMenuContent && !this.isMenuContentLoading) {
            this.preloadHeaderMenuContent();
        }
    }

    /**
     * Busca e processa os links dinâmicos da planilha Google.
     */
    async getDynamicLinksContent() {
        // Coleta todos os dados relevantes do usuário do token tokiuz
        let userData = { f: [], fl: [], ff: [] }; // Garante que 'f', 'fl', 'ff' sejam arrays
        try {
            const token = getCookie('tokiuz');
            if (token) {
                const decoded = decodeJwt(token);
                
                const userFunctions = Array.isArray(decoded.f) ? decoded.f.map(String) : [];
                const userFunctionsL = []; // para fl
                const userFunctionsF = []; // para ff

                userFunctions.forEach(func => {
                    const parts = func.split('.');
                    if (parts.length > 1) {
                        userFunctionsL.push(parts[0]);
                        userFunctionsF.push(parts.slice(1).join('.')); // Handle "29.1.1" -> ff: "1.1"
                    } else {
                        userFunctionsL.push(func); // Sem ponto, fl é a string inteira
                        userFunctionsF.push("");   // Sem ponto, ff é vazio
                    }
                });
                
                userData = {
                    g: String(decoded.g || ''), // PM Number
                    t: String(decoded.t || ''), // Rank
                    e: String(decoded.e || ''), // Entity
                    p: String(decoded.p || ''), // Fraction/Section
                    r: String(decoded.r || ''), // Region
                    u: String(decoded.u || ''), // Accounting Unit
                    c: String(decoded.c || ''), // Fraction/Section Code
                    f: userFunctions,           // Lista completa [f]
                    fl: userFunctionsL,         // Lista "antes do ponto" [fl]
                    ff: userFunctionsF          // Lista "depois do ponto" [ff]
                };
            }
        } catch (e) {
            console.error('SisPMG+ [UI]: Falha ao decodificar tokiuz', e);
        }

        try {
            const sheetId = '1e93QrFOFFHRhuq1_5J6scH_JTAEWe4Rk-mIZ1SYaQ1s';
            const sheetName = 'links';
            
            const response = await sendMessageToBackground('obterPlanilhaGviz', {
                sheetId: sheetId,
                sheetName: sheetName
            });

            if (!response || !response.success) {
                throw new Error(response?.error || 'Falha ao buscar links dinâmicos via background.');
            }
            
            let text = response.text;
            
            // Aplicar a lógica de limpeza do usuário
            let jsonString = text.substring(47).slice(0, -2);
            jsonString = jsonString.replace(/\[null/g, "\[\{\"v\":\"NAO\"}"); // Mantido da lógica original
            jsonString = jsonString.replace(/\,null/g, "\,{\"v\":\"\"}");
            jsonString = jsonString.replace(/\:null/g, "\:\"\"");
            
            const json = JSON.parse(jsonString).table;
            let itemsHTML = '';
            
            // Estrutura esperada (baseado no screenshot e lógica anterior):
            // C[0]: Abrangência
            // C[1]: Texto
            // C[2]: Link
            
            if (json.rows && json.rows.length > 0) {
                for (const row of json.rows) {
                    if (row.c && row.c.length >= 1) {
                        const abrangencia = row.c[0]?.v || '';
                        const texto = row.c[1]?.v || '';
                        const link = row.c[2]?.v || '';

                        // 1. Verifica se o usuário tem acesso baseado na abrangência
                        const hasAccess = checkAbrangencia(abrangencia, userData);

                        if (hasAccess) {
                            // 2. Decide o que renderizar: Subtítulo, Separador ou Link
                            if (!link && texto) {
                                // Subtítulo (link vazio, texto preenchido)
                                itemsHTML += `<div class="sispmg-menu-subtitle">${texto}</div>`;
                            } else if (!link && !texto) {
                                // Separador (link vazio, texto vazio)
                                itemsHTML += `<div class="sispmg-menu-separator"></div>`;
                            } else if (link && texto) {
                                // Item de menu normal (link e texto preenchidos)
                                itemsHTML += `
                                    <a href="${link}" target="_blank" class="sispmg-menu-item">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6m4-3h6v6m-11 5L21 3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                                        <span>${texto}</span>
                                    </a>
                                `;
                            }
                            // Se tiver link mas não tiver texto, ou outras combinações não especificadas, não renderiza nada.
                        }
                    }
                }
            }
            
            if (itemsHTML) {
                return itemsHTML; // Retorna os links dinâmicos, subtítulos e separadores
            }
            return ''; // Retorna string vazia se não houver links

        } catch (e) {
            console.error("SisPMG+ [UI]: Erro ao carregar links dinâmicos.", e);
            try {
                const { reportarErro } = await import('../../common/comunicacao.js');
                reportarErro(e, 'INTRANET');
            } catch (reportErr) {
                console.error("Falha ao reportar erro da UI para a planilha:", reportErr);
            }
            return '<div class="sispmg-menu-item sispmg-menu-error">Erro ao carregar links.</div>';
        }
    }

    async getHeaderMenuContent() {
        let moduleItems = '';
        
        // SIC3 v3.0 Botão — controlado pela abrangência da planilha (chave: "sic3")
        const _sic3Permitido = (() => {
            try {
                const cached = sessionStorage.getItem('sispmg_modulos_permitidos');
                if (!cached) return true; // Cache ainda não disponível: exibe por padrão
                return JSON.parse(cached).includes('sic3');
            } catch (_) { return true; }
        })();
        if (_sic3Permitido) {
            moduleItems += `
            <div id="sic3-btn" class="sispmg-menu-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-5 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z"/>
                </svg>
                <span>SIC3 v3.0</span>
            </div>
        `;
        }

        const isPrincipalPage = window.location.hostname === 'principal.policiamilitar.mg.gov.br';
        const isSicorPage = window.location.pathname.startsWith('/SICOR/');

        if (isPrincipalPage) {
             moduleItems += `
                 <div id="config-birthdays-btn" class="sispmg-menu-item">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2a5 5 0 0 0-5 5c0 1.84.97 3.47 2.43 4.39A8.002 8.002 0 0 0 4 20a1 1 0 1 0 2 0a6 6 0 0 1 12 0a1 1 0 1 0 2 0a8.002 8.002 0 0 0-5.43-6.61A4.992 4.992 0 0 0 17 7a5 5 0 0 0-5-5zm0 2a3 3 0 1 1 0 6a3 3 0 0 1 0-6z" fill="currentColor"/></svg>
                    <span>Configurar aniversariantes</span>
                </div>
            `;
        }
        /*
        if (agendaModuleEnabled && isPrincipalPage) {
            moduleItems += `
                <div id="config-agenda-btn" class="sispmg-menu-item">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M19 4h-1V3a1 1 0 1 0-2 0v1H8V3a1 1 0 0 0-2 0v1H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm-1 14H6V9h12v9zm0-11H6V7h12v2z"/></svg>
                    <span>Configurar Agenda</span>
                </div>
           `;
       }
        */
        if (isSicorPage && this.modules['SICOR']) {
             moduleItems += `
                <div id="config-sicor-btn" class="sispmg-menu-item">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M12 9.5a2.5 2.5 0 110 5 2.5 2.5 0 010-5zm0 1.5a1 1 0 100 2 1 1 0 000-2z" /><path fill-rule="evenodd" clip-rule="evenodd" d="M11.294 2.05a1 1 0 011.412 0l.544.544a1 1 0 001.02.29l1.242-.43a1 1 0 011.173.743l.26 1.282a1 1 0 00.75.75l1.282.26a1 1 0 01.743 1.173l-.43 1.242a1 1 0 00.29 1.02l.544.544a1 1 0 010 1.412l-.544.544a1 1 0 00-.29 1.02l.43 1.242a1 1 0 01-.743 1.173l-1.282.26a1 1 0 00-.75.75l-.26 1.282a1 1 0 01-1.173.743l-1.242-.43a1 1 0 00-1.02.29l-.544.544a1 1 0 01-1.412 0l-.544-.544a1 1 0 00-1.02-.29l-1.242.43a1 1 0 01-1.173-.743l-.26-1.282a1 1 0 00-.75-.75l-1.282-.26a1 1 0 01-.743-1.173l.43-1.242a1 1 0 00-.29-1.02l-.544-.544a1 1 0 010-1.412l.544-.544a1 1 0 00.29-1.02l-.43-1.242a1 1 0 01.743-1.173l1.282-.26a1 1 0 00.75-.75l.26-1.282a1 1 0 011.173-.743l1.242.43a1 1 0 001.02.29l.544.544zM12 7.75a4.25 4.25 0 100 8.5 4.25 4.25 0 000-8.5z" /></svg>
                    <span>Configurar Módulo SICOR</span>
                </div>
            `;
        }

        // Adiciona item do menu para Extração de Convênios (SIRCONV)
        const isSirconvConveniosPage = window.location.href.includes('/lite/convenio/');
        if (isSirconvConveniosPage && this.modules['SIRCONV Dashboard']) {
            moduleItems += `
               <div id="sirconv-dashboard-btn" class="sispmg-menu-item">
                   <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><path d="M3 13h8V3H3v10zm0 8h8v-6H3v6zm10 0h8V11h-8v10zm0-18v6h8V3h-8z"/></svg>
                   <span>Dashboard de Convênios</span>
               </div>
           `;
        }

        if (isSirconvConveniosPage && this.modules['Extração de Convênios']) {
             moduleItems += `
                <div id="config-sirconv-convenios-btn" class="sispmg-menu-item">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 2a1 1 0 0 0-1 1v1H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-4V3a1 1 0 1 0-2 0v1H8V3a1 1 0 0 0-1-1zM4 8h16v12H4V8zm2 3v2h3v-2H6zm5 0v2h7v-2h-7zm-5 4v2h7v-2H6zm9 0v2h3v-2h-3z"/>
                    </svg>
                    <span>Extração de Convênios</span>
                </div>
            `;
        }

        // <-- ADICIONADO: Item do menu para Extração de Unidades -->
        const isUnidadesPage = window.location.href.startsWith('https://intranet.policiamilitar.mg.gov.br/legado/operacoes/unidades/');
        if (isUnidadesPage && this.modules['Unidades']) {
             moduleItems += `
                <div id="config-unidades-btn" class="sispmg-menu-item">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5zm0 2.18l8 3.6v8.55c0 4.45-3.08 8.64-7.5 9.65v-9.98H10v9.98C5.58 24.97 2.5 20.78 2.5 16.33V7.78l8-3.6zM8 9v2h8V9H8zm0 4v2h8v-2H8z"/>
                    </svg>
                    <span>Extração de Unidades</span>
                </div>
            `;
        }
        // <-- FIM DA ADIÇÃO -->

        const dynamicLinksContent = await this.getDynamicLinksContent();

        let finalContent = `<div class="sispmg-menu-header">SisPMG+ Intranet</div>`;
        
        // Início da Modificação: Inverter a ordem
        if (moduleItems.trim() !== '') {
            finalContent += moduleItems;
        }

        // Adicionar separador se ambos existirem
        if (dynamicLinksContent && moduleItems.trim() !== '' && (dynamicLinksContent.includes('sispmg-menu-item') || dynamicLinksContent.includes('sispmg-menu-subtitle'))) {
            finalContent += '<div class="sispmg-menu-separator"></div>';
        }
        
        if (dynamicLinksContent) {
            finalContent += dynamicLinksContent;
        }
        
        // Se não houver absolutamente nada
        if (moduleItems.trim() === '' && !dynamicLinksContent.includes('sispmg-menu-item') && !dynamicLinksContent.includes('sispmg-menu-subtitle')) {
             finalContent += '<div class="sispmg-menu-item">Nenhuma ação disponível.</div>';
        }
        // Fim da Modificação
        
        return finalContent;
    }


    attachMenuEventListeners(menu) {
        const sic3V3Button = menu.querySelector('#sic3-btn');
        if (sic3V3Button) {
            sic3V3Button.addEventListener('click', async () => {
                this.closeHeaderMenu();
                await this.iniciarSic3V3();
            });
        }

        const birthdaysButton = menu.querySelector('#config-birthdays-btn');
        if (birthdaysButton && this.modules['Aniversariantes']) {
            birthdaysButton.addEventListener('click', () => {
                this.modules['Aniversariantes']?.showConfigModal();
                this.closeHeaderMenu();
            });
        }

        const agendaButton = menu.querySelector('#config-agenda-btn');
        if (agendaButton && this.modules['Agenda']) {
            agendaButton.addEventListener('click', () => {
                this.modules['Agenda']?.showConfigModal();
                this.closeHeaderMenu();
            });
        }

        const sicorButton = menu.querySelector('#config-sicor-btn');
        if (sicorButton && this.modules['SICOR']) {
             sicorButton.addEventListener('click', () => {
                this.modules['SICOR'].renderSicorModal();
                this.closeHeaderMenu();
            });
        }

        const sirconvConveniosButton = menu.querySelector('#config-sirconv-convenios-btn');
        if (sirconvConveniosButton && this.modules['Extração de Convênios']) {
             sirconvConveniosButton.addEventListener('click', () => {
                this.modules['Extração de Convênios'].showConfig();
                this.closeHeaderMenu();
            });
        }

        const sirconvDashboardButton = menu.querySelector('#sirconv-dashboard-btn');
        if (sirconvDashboardButton && this.modules['SIRCONV Dashboard']) {
            sirconvDashboardButton.addEventListener('click', () => {
                this.modules['SIRCONV Dashboard'].showDashboard();
                this.closeHeaderMenu();
            });
        }

        // <-- ADICIONADO: Event listener para Extração de Unidades -->
        const unidadesButton = menu.querySelector('#config-unidades-btn');
        if (unidadesButton && this.modules['Unidades']) {
             unidadesButton.addEventListener('click', () => {
                this.modules['Unidades'].showConfig();
                this.closeHeaderMenu();
            });
        }
        // <-- FIM DA ADIÇÃO -->
        
        // Listeners para os botões estáticos removidos

        // Adiciona listener para fechar o menu ao clicar em um link
        menu.querySelectorAll('a.sispmg-menu-item').forEach(link => {
            link.addEventListener('click', () => this.closeHeaderMenu());
        });
    }

    updateMenu() {
        const menu = document.getElementById('sispmg-plus-header-menu');
        if (menu && this.preloadedMenuContent) {
            menu.firstElementChild.innerHTML = this.preloadedMenuContent;
            this.attachMenuEventListeners(menu);
        }
    }
    
    openFullscreenIframe(url, id) {
        this.closeHeaderMenu(); // Garante que o menu feche ao abrir o iframe
        const containerId = `sispmg-fullscreen-iframe-container-${id}`;
        let iframeContainer = document.getElementById(containerId);

        // Oculta todos os outros iframes abertos para garantir que apenas um esteja visível
        document.querySelectorAll('[id^="sispmg-fullscreen-iframe-container-"]').forEach(container => {
            if (container.id !== containerId) {
                container.style.display = 'none';
            }
        });

        document.body.classList.add('sispmg-fullscreen-active');

        if (iframeContainer) {
            // Se o contêiner já existe, apenas o torna visível
            iframeContainer.style.display = 'block';
        } else {
            // Se não existe, cria um novo
            iframeContainer = document.createElement('div');
            iframeContainer.id = containerId;
            iframeContainer.style.display = 'block'; // Garante que seja visível ao ser criado
            
            iframeContainer.innerHTML = `
                <iframe src="${url}"></iframe>
                <button id="sispmg-iframe-back-button-${id}" class="btn-sair btn-dark" title="Voltar à Intranet">
                    <i class="fas fa-sign-out-alt"></i> SAIR
                </button>
            `;
            document.getElementById('sispmg-plus-container').appendChild(iframeContainer);

            document.getElementById(`sispmg-iframe-back-button-${id}`).onclick = () => this.restoreOriginalPage(id);
        }
    }
    
    restoreOriginalPage(id) {
        const containerId = `sispmg-fullscreen-iframe-container-${id}`;
        const iframeContainer = document.getElementById(containerId);

        if (iframeContainer) {
            // Em vez de remover, apenas oculta o contêiner do iframe
            iframeContainer.style.display = 'none';
        }
        
        // Sempre remove a classe do body para restaurar a visualização da página original
        document.body.classList.remove('sispmg-fullscreen-active');
    }
    
    createModal(title, contentHTML, onSave = null, customButtons = [], options = {}) {
        document.querySelector('.sispmg-plus-modal')?.remove();
        const modal = document.createElement('div');
        modal.className = 'sispmg-plus-menu sispmg-plus-modal';
        modal.id = `sispmg-modal-${Date.now()}`;
        
        let buttonsHTML = customButtons.map((btn, i) => `<button id="custom-btn-${i}" class="${btn.className || ''}">${btn.text}</button>`).join('');
        if (onSave) {
            buttonsHTML += `<button class="sispmg-modal-btn-secondary">Cancelar</button><button class="sispmg-modal-btn-primary">Salvar</button>`;
        }

        modal.innerHTML = `
            <div class="sispmg-menu-header">${title}<button class="sispmg-modal-close-btn">&times;</button></div>
            <div class="sispmg-modal-body-content">${contentHTML}</div>
            <div class="sispmg-modal-actions">${buttonsHTML}</div>
        `;

        document.getElementById('sispmg-plus-container').appendChild(modal);
        
        modal.querySelector('.sispmg-modal-close-btn').onclick = () => modal.remove();

        if (onSave) {
            modal.querySelector('.sispmg-modal-btn-primary').onclick = () => onSave(modal);
            modal.querySelector('.sispmg-modal-btn-secondary').onclick = () => modal.remove();
        }
        customButtons.forEach((btn, i) => { modal.querySelector(`#custom-btn-${i}`).onclick = () => btn.action(modal); });

        return modal;
    }

    showLoader(message = '') {
        this.hideLoader(); // Garante que não haja loaders duplicados
        const loader = document.createElement('div');
        loader.id = 'sispmg-loader-overlay';
        
        // Estrutura do loader, com espaço para a mensagem
        loader.innerHTML = `
            <div style="display: flex; flex-direction: column; align-items: center; gap: 15px;">
                <div class="sispmg-spinner"></div>
                <div id="sispmg-loader-message" style="color: #fff; font-size: 16px; font-weight: 600; text-shadow: 0 1px 3px rgba(0,0,0,0.5); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">${message}</div>
            </div>
        `;
        document.getElementById('sispmg-plus-container').appendChild(loader);
    }

    updateLoaderMessage(message) {
        const msgElement = document.getElementById('sispmg-loader-message');
        if (msgElement) {
            msgElement.innerText = message;
        }
    }

    hideLoader() {
        document.getElementById('sispmg-loader-overlay')?.remove();
    }

    closeHeaderMenu() {
        if (!this.menuVisible) return; // Evita múltiplas chamadas
        if (this.menuCloseTimer) clearTimeout(this.menuCloseTimer);
        this.menuCloseTimer = null;
        this.menuVisible = false;
        const menu = document.getElementById('sispmg-plus-header-menu');
        if (menu) {
            menu.remove();
        }
    }

    async iniciarSic3V3() {
        console.log("[SIC3 v3.0 Log] [UI-Extração] Iniciando fluxo de ativação do SIC3 v3.0...");
        this.showLoader("Identificando sua unidade e município...");
        
        try {
            const token = getCookie('tokiuz');
            if (!token) {
                console.error("[SIC3 v3.0 Log] [UI-Extração] Cookie 'tokiuz' não encontrado.");
                alert("Token de autenticação 'tokiuz' não encontrado. Redirecionando para a página de login da Intranet...");
                this.hideLoader();
                window.location.href = "https://intranet.policiamilitar.mg.gov.br/autenticacaosso/login.jsf";
                return;
            }
            
            // Log do token bruto (apenas indicativo para não poluir demais)
            console.log("[SIC3 v3.0 Log] [UI-Extração] Cookie 'tokiuz' obtido com sucesso.");
            
            const decoded = decodeJwt(token);
            if (!decoded) {
                console.error("[SIC3 v3.0 Log] [UI-Extração] Falha ao decodificar JWT do token 'tokiuz'.");
                alert("Não foi possível extrair os dados do usuário a partir do token. Tente recarregar a página.");
                this.hideLoader();
                return;
            }
            
            // Detalhando o processo de extração e a definição de cada chave
            console.log("[SIC3 v3.0 Log] [UI-Extração] Credenciais decodificadas do Tokiuz (obtidas do cookie de autenticação JWT):", {
                g_numeroPM: decoded.g,             // Obtido da chave 'g' do JWT (Número da matrícula/PM do militar)
                n_nome: decoded.n,                 // Obtido da chave 'n' do JWT (Nome completo do militar)
                t_postoGraduacao: decoded.t,       // Obtido da chave 't' do JWT (Posto ou Graduação)
                e_codigoRegiao: decoded.e,         // Obtido da chave 'e' do JWT (Código numérico da regional/RPM no portal)
                p_unidade: decoded.p,              // Obtido da chave 'p' do JWT (Unidade/Seção funcional raiz)
                r_regiaoPM: decoded.r,             // Obtido da chave 'r' do JWT (Nome textual da regional/RPM)
                u_codigoUnidade: decoded.u,        // Obtido da chave 'u' do JWT (Código da unidade)
                c_codigoSecao: decoded.c,          // Obtido da chave 'c' do JWT (Código da seção)
                f_funcoes: decoded.f               // Obtido da chave 'f' do JWT (Array de funções/perfis atribuídos ao usuário)
            });

            // A lógica de verificação de administrador (isAdmin) agora é determinada após a resolução do nome da seção do usuário (se contém ALMOXARIFADO ou SOFI).
            
            // Tratamento da RPM amigável a partir do Tokiuz
            let rpmNome = "";
            if (decoded.r) {
                rpmNome = String(decoded.r).replace('ª', '').trim();
            } else if (decoded.e) {
                rpmNome = String(decoded.e).trim() + " RPM";
            }
            console.log(`[SIC3 v3.0 Log] [UI-Tratamento] RPM amigável tratada para planilhas: "${rpmNome}" (com base em r: "${decoded.r}", e: "${decoded.e}")`);

            // 1. Verificar se já existem informações completas do usuário no storage local, se coincidem com o token ativo ou se há overrides
            const storageResult = await sendMessageToBackground('getSettings', { keys: ['sic3_user_info', 'sic3_tokiuz_override'] });
            const cachedInfo = (storageResult?.success && storageResult.value?.sic3_user_info) ? storageResult.value.sic3_user_info : null;
            const tokiuzOverride = (storageResult?.success && storageResult.value?.sic3_tokiuz_override) ? storageResult.value.sic3_tokiuz_override : null;
            
            if (tokiuzOverride) {
                console.log("[SIC3 v3.0 Log] [UI-Extração] Aplicando OVERRIDES de simulação no Tokiuz:", tokiuzOverride);
                Object.assign(decoded, tokiuzOverride);
                
                // Recalcula a RPM amigável com base nos dados simulados
                if (tokiuzOverride.r || tokiuzOverride.e) {
                    if (decoded.r) {
                        rpmNome = String(decoded.r).replace('ª', '').trim();
                    } else if (decoded.e) {
                        rpmNome = String(decoded.e).trim() + " RPM";
                    }
                    console.log(`[SIC3 v3.0 Log] [UI-Tratamento] RPM amigável recalculada para os Overrides: "${rpmNome}"`);
                }
            }
            
            let userInfoFinal = null;
            
            if (cachedInfo && 
                String(cachedInfo.numeroPM) === String(decoded.g) && 
                String(cachedInfo.codigoSecao) === String(decoded.c)) {
                
                console.log("[SIC3 v3.0 Log] [UI-Extração] Cadastro em cache compatível encontrado no Storage Local. Pulando consulta na rede.", cachedInfo);
                userInfoFinal = cachedInfo;
                // Recalcula isAdmin para refletir qualquer mudança de unidade ou nas regras ('ALMOXARIFADO' ou 'SOFI')
                const secaoUpper = String(userInfoFinal.secao || '').toUpperCase();
                userInfoFinal.isAdmin = secaoUpper.includes('ALMOXARIFADO') || secaoUpper.includes('SOFI');
            } else {
                if (cachedInfo) {
                    console.log("[SIC3 v3.0 Log] [UI-Extração] Cache do usuário obsoleto ou de outro PM. Iniciando consulta de unidades...");
                } else {
                    console.log("[SIC3 v3.0 Log] [UI-Extração] Nenhum dado de usuário em cache. Solicitando busca de unidades ao background...");
                }
                
                // Solicitar busca ao background se não tiver cache válido
                const response = await sendMessageToBackground('sic3-identify-user', { e: decoded.e, c: decoded.c });
                
                if (!response || !response.success) {
                    const errMsg = response?.error || "Falha na resposta do background ao identificar unidade.";
                    throw new Error(errMsg);
                }
                
                console.log("[SIC3 v3.0 Log] [UI-Extração] Identificação de unidade realizada com sucesso pelo background:", response);
                
                const secaoUpper = String(response.secao || '').toUpperCase();
                const usuarioEhAdmin = secaoUpper.includes('ALMOXARIFADO') || secaoUpper.includes('SOFI');
                
                userInfoFinal = {
                    codigoSecao: String(response.codigoSecao),
                    secao: response.secao,
                    municipio: response.municipio,
                    codigoMunicipio: String(response.codigoMunicipio),
                    hierarchyPath: response.hierarchyPath,
                    // Informações do tokiuz do usuário para o painel
                    numeroPM: String(decoded.g || ''),
                    postoGraduacao: decoded.t || '',
                    nome: decoded.n || '',
                    codigoRegiao: String(decoded.e || ''),
                    nomeRegiao: decoded.r || '',
                    nomeUnidade: decoded.p || '',
                    codigoUnidade: String(decoded.u || ''),
                    isAdmin: usuarioEhAdmin,
                    timestamp: Date.now()
                };
                
                // Salvar informações no storage local para uso posterior do SIC3 v3.0 e evitar nova busca durante a sessão
                await sendMessageToBackground('setStorage', {
                    sic3_user_info: userInfoFinal
                });
                console.log("[SIC3 v3.0 Log] [UI-Gravação] Novas credenciais e dados da unidade gravados no storage local.");
            }
            
            this.updateLoaderMessage("Carregando o SIC3 v3.0...");
            console.log(`[SIC3 v3.0 Log] [UI-Redirecionamento] Abrindo SIC3 v3.0 para o município: ${userInfoFinal.municipio}. Admin: ${userInfoFinal.isAdmin}`);
            
            // Salvar parâmetros de inicialização no storage para o SIC3 v3.0 ler e consumir de forma limpa (sem parâmetros na URL)
            await sendMessageToBackground('setStorage', {
                sic3_url_params: {
                    municipio: userInfoFinal.municipio,
                    rpm: rpmNome,
                    secao: userInfoFinal.secao
                }
            });
            console.log("[SIC3 v3.0 Log] [UI-Gravação] Parâmetros de inicialização salvos no storage:", {
                municipio: userInfoFinal.municipio,
                rpm: rpmNome,
                secao: userInfoFinal.secao
            });
            
            await sendMessageToBackground('openSettingsPage', {
                page: 'modules/sic3/sic3.html'
            });
            
        } catch (error) {
            console.error("[SIC3 v3.0 Log] [UI-Erro] Erro no fluxo iniciarSic3V3:", error);
            alert("Erro ao iniciar o SIC3 v3.0: " + error.message);
        } finally {
            this.hideLoader();
        }
    }
}